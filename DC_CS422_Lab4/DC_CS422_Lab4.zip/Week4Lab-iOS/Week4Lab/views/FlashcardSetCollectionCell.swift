//
//  FlashcardSetCollectionCell.swift
//
//  Created by Andrew Taylor on 1/22/23.
//

import UIKit

class FlashcardSetCollectionCell: UICollectionViewCell {
    @IBOutlet weak var myLabel: UILabel!
}
